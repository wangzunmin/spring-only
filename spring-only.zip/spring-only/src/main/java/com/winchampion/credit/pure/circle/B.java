package com.winchampion.credit.pure.circle;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class B {
	@Resource
	private C c;

	/*public void setC(C c) {
		this.c = c;
	}*/
	
	
}
