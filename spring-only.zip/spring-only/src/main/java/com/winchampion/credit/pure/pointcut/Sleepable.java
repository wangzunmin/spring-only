package com.winchampion.credit.pure.pointcut;

public interface Sleepable {
	  int sleep(); 
}
