package com.winchampion.credit.pure.circle;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

@Component
public class C {
	/*@Resource
	private A a;*/

	/*public void setA(A a) {
		this.a = a;
	}*/
	
	
}
