package com.winchampion.credit.pure.proxy.jdk;

public class Person {

}
