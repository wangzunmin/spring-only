package com.winchampion.credit.pure.aop;

public interface UserService {
	/** 
     * 目标方法  
     */  
    public abstract void add(); 
}
