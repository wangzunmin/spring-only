package com.winchampion.credit.pure.redis.test;

public class Demo {
	private String name;
	
	
}
