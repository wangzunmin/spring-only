package com.winchampion.credit.pure.proxy.cglib;

public class HelloService {
	public void sayHello(){
		System.out.println("hello aop");
	}
}
