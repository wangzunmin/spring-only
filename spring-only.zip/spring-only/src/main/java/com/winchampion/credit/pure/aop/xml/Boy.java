package com.winchampion.credit.pure.aop.xml;
/**
 * 目标对象
 * @author wangzunmin
 *
 */
public class Boy {
	public void sing() {
		System.out.println("男孩在唱歌");
	}
}
