package com.winchampion.credit.pure.annotation;

import org.springframework.stereotype.Component;

@Component("roleTests")
public class Role {

	public void getRole(){
		System.out.println("role");
	}
}
