package com.winchampion.credit.pure.proxy.jdk;

public interface PersonService {
	public int savePerson(Person person);
}
