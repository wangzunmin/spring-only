package com.winchampion.credit.pure.proxy.jdk;
/**
 * 目标对象
 * @author WZM
 *
 * 2018年9月3日
 */
public class PersonServiceimpl implements PersonService{

	public int savePerson(Person person) {
		return 0;
	}
	
}
