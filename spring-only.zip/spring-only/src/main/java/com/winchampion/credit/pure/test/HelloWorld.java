package com.winchampion.credit.pure.test;


public class HelloWorld {
	
	public void hello(){
		/*int a = 1/0;*/
		System.out.println("hello");
	}
	
}
